# PHREEZE TEST RUNNER W/ CODE COVERAGE REPORT
# This is a test runner script for PHREEZE
# See README for setup instructions
#
rm -rf ./coverage
phpunit --coverage-html ./coverage ./Tests/AllTests